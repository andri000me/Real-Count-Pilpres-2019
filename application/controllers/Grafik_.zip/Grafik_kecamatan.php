<?php
class Grafik_kecamatan extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->model('model_suara');
        chek_session();
    }

 function index(){
  if (isset($_POST['submit'])) {
    $id = $this->input->post('kecamatan');
    $data['idKec'] = $this->model_suara->Pilpres_kec($id);
    $data['country'] = $this->model_suara->fetch_partai();
    $this->template->load('template','grafik/kecamatan/tampil',$data);
    
  }
  



 /*------------------------*/



}
}

  ?>

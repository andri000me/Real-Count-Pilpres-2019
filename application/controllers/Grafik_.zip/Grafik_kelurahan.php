<?php
class Grafik_kelurahan extends CI_Controller{

    function __construct() {
        parent::__construct();
        $this->load->model('model_suara');
        chek_session();
    }

 function index(){
  if (isset($_POST['submit'])) {
    $id = $this->input->post('kelurahan');
    $data['idKabkota'] = $this->model_suara->Pilpres_kel($id);
    $data['country'] = $this->model_suara->fetch_partai();
    $this->template->load('template','grafik/kelurahan/tampil',$data);
    
  }
}

function grafik_kel(){
        
        $data['country'] = $this->model_suara->fetch_provinsi();
        $this->template->load('template','grafik/kelurahan/test',$data);
    }
}

  ?>
